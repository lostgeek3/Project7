本单元测试对addCourseForm.dart中的AddCourseDialog类进行单元测试，并采用了Mock，用MockCourseNotifier代替软件中从数据库中读取的课程表信息，用于测试添加课程时的”课程时间冲突“判断。

本单元测试的语句覆盖率达98.9%，测试报告位于./html/index.html。


